test_distance_motion_obstacle_trial.csv

distances
1: 0.2m, 2: 0.4m, 3: 0.6m, 4: 0.8m, 5: 1.0m

motion
slow: 5600 ms delay forth, 5600 ms delay back
fast: 800 ms delay forth, 800 ms delay back

obstacle
1: no bricks (free air), 2: bricks at distance halfway

trial
10 trials overall of each above combination

The '0' line is kind of arbitrary at the end of the blue bins. The center of the
flap board is actually 25 cm further back. Other dimensions into a final schematic
will be made.

25 cm antenna separation (measured from the white arrows)

