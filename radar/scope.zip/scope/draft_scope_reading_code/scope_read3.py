from instrumental import list_instruments
paramsets = list_instruments()